from tkinter import *

scale=1.5
root = Tk()
root.geometry("700x500")
canvas = Canvas(root, bg="light grey", width=700*scale, height=500*scale)

#Whiteboard
canvas_clock = Canvas(root,width=500,height=500)
canvas_clock.create_rectangle(120, 10, 500, 270, fill="white")
canvas_clock.grid(row=0,column=0)

#Window
canvas.create_rectangle(520*scale, 70*scale, 690*scale, 250*scale, fill="black")
#Window line
canvas.create_rectangle(525*scale, 75*scale, 685*scale, 245*scale, fill="light blue")
canvas.create_line(520*scale, 160*scale, 690*scale, 160*scale, fill="black", width=3)
canvas.create_line(605*scale, 69*scale, 605*scale, 251*scale, fill="black", width=3)
canvas.create_line(520*scale, 70*scale, 690*scale, 70*scale, fill="black", width=3)
canvas.create_line(520*scale, 250*scale, 690*scale, 250*scale, fill="black", width=3)
canvas.create_line(520*scale, 69*scale, 520*scale, 251*scale, fill="black", width=3)
canvas.create_line(690*scale, 69*scale, 690*scale, 251*scale, fill="black", width=3)

#Clock
coordinates = 10*scale, 10*scale, 100*scale, 100*scale
canvas.create_oval(coordinates, outline="Black", width=3, fill="white")
canvas.create_line(55*scale, 29*scale, 56*scale, 55*scale, fill="black", width=2)
canvas.create_line(90*scale, 55*scale, 55*scale, 55*scale, fill="black", width=2)

#0
canvas.create_line(55*scale, 10*scale, 55*scale, 15*scale,fill="black", width=1.5)
#6
canvas.create_line(55*scale, 100*scale, 55*scale, 95*scale,fill="black", width=1.5)
#3
canvas.create_line(100*scale, 55*scale, 95*scale, 55*scale,fill="black", width=1.5)
#9
canvas.create_line(10*scale, 55*scale, 15*scale, 55*scale,fill="black", width=1.5)




root.title("Alpha")
root.mainloop()