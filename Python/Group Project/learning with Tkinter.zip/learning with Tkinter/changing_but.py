from tkinter import *


def switchButtonState():
    if (button1['state'] == NORMAL):
        button1['state'] = DISABLED
    else:
        button1['state'] = NORMAL


app = Tk()
app.geometry("300x100")
button1 = Button(app, text="Python Button 1",
                    state=DISABLED)
button2 = Button(app, text="EN/DISABLE Button 1",
                    command=switchButtonState)
button1.pack(side=LEFT)
button2.pack(side=RIGHT)
app.mainloop()


from tkinter import *
from math import *

root = Tk()
height = 400
width = 500
canvas = Canvas(root, width=width, height=height, bg="grey")
canvas.grid(row=0, column=0, columnspan=3)
generation = 2
gen_up = StringVar(value=str(generation - 1))

def deleting_a_label():
    button1['text'] = "test"


my_button = Button(root, text="Delete label!",command=deleting_a_label,state=NORMAL).grid(row=2,column=0)
button1 = Button(root, text=f"test{generation}.",
                    state=NORMAL,command=deleting_a_label)
print(button1['textvariable'])
root.mainloop()