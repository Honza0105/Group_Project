from tkinter import *

root = Tk()

my_Label = Label(root, text="Hello World!")

my_Label.pack()

root.mainloop()
