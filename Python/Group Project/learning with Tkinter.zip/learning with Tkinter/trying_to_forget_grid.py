from tkinter import *
from math import *

root = Tk()
height = 400
width = 500
canvas = Canvas(root, width=width, height=height, bg="grey")
canvas.grid(row=0, column=0, columnspan=3)
generation = 2
gen_up = StringVar(value=str(generation - 1))

def deleting_a_label():
    gen_up.set(3)
    button1['state']=DISABLED


my_button = Button(root, text="Delete label!",command=deleting_a_label,state=NORMAL).grid(row=2,column=0)
button1 = Button(root, textvariable=gen_up,
                    state=NORMAL,command=deleting_a_label)
button1.grid(row=3,column=3)
print(button1['textvariable'])
root.mainloop()