def stuplujeme(w,x,y,z,):
    return(w)

muj_tuple = 1,2,3,4
print(list(muj_tuple))

print(stuplujeme(*muj_tuple))
